# YOOPro-Content-Fix is a Joomla! 3 content plugin
Allows use of something like  &lt;hr id="system-readmore" /&gt; tag in YOOTheme PRO Page Builder articles. 

Use &lt;hr class="yoopro-content-readmore" /&gt; instead, inside YOOTheme Content Builder

If you want to hide some section when in context "com_content.article" (single article view), inside Content Builder add class 'yoopro-content-hide'.

Please remember to enable pluing once installed.
