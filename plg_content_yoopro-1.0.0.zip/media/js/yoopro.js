/**
 * Created by ladyj on 14/03/17.
 */
jQuery(function() {
    jQuery('.yoopro-content-hide').remove();
});
